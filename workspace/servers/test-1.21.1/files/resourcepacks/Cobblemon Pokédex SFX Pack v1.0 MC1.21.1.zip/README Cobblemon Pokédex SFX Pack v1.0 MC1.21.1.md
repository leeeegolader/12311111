## **Cobblemon Pokédex SFX Pack**
The Cobblemon Pokédex sound effects will undergo a partial overhaul with this resource pack.

### **Info**
I edited/used sound effects from the Pokémon games, Pokémon the animated TV series.

### **Showcase**
Coming Soon

### **Known issues**
Contact me on (Discord: WizzStar) if you find any.

## **Dependecies**
[**Cobblemon**](https://www.curseforge.com/minecraft/mc-mods/cobblemon)

### **To-do**
* _Nothing yet_

## **Credits**
_I did not create or do not own any of these sound effects!_  
All credit goes to the rightful creators/owners.\
**__The pack logo is custom made by me; it's inspired by the RGBY in-game PC.__**

_According to Bulbapedia "All of the background music and sound effects used in the games (RGBY), all of which were composed solely by Junichi Masuda. This includes Pokémon cries and Pokédex entries read by "Dexter", Ash's Pokédex."_

[Junichi Masuda](https://bulbapedia.bulbagarden.net/wiki/Junichi_Masuda)\
[Game Freak, Inc.](https://bulbapedia.bulbagarden.net/wiki/Game_Freak)   
[The Pokémon Company](https://bulbapedia.bulbagarden.net/wiki/The_Pok%C3%A9mon_Company)\
[Nintendo](https://bulbapedia.bulbagarden.net/wiki/Nintendo)

### **Contact**
_**Discord: WizzStar**_\
You can contact me for issues, but also requests and/or ideas.